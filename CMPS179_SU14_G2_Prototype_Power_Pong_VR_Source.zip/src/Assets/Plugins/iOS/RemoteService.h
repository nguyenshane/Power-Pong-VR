//
//  RemoteService.h
//  RemoteCentral
//
//  Created by John Murray on 11/2/13.
//  Copyright (c) 2013 Seebright, Inc. All rights reserved.
//

#ifndef RemoteService_h
#define RemoteService_h

#define REMOTE_SERVICE_UUID           @"D6F31BEB-ED94-4F5A-A751-AB46C597D5DA"
#define INPUT_CHARACTERISTIC_UUID    @"561ACFEA-385C-4199-AD85-405942DB2E78"
#endif
