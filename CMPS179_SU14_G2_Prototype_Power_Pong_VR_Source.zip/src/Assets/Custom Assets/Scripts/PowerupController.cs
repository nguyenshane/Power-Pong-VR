﻿using UnityEngine;
using System.Collections;

public class PowerupController : MonoBehaviour {

	public int numberOfPowerups;
	public int powerupsGenerated;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
